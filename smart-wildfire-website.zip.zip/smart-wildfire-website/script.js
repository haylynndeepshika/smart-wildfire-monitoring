/**
 * EMBERWATCH — Smart Wildfire Monitoring & Prediction
 * Interactive script for dashboard, navigation, risk simulation,
 * interactive map, accordions, and animations.
 */

function initEmberWatch() {
  'use strict';

  /* ============================================================
     1. TIME DISPLAY & HEADER SCROLL STATE
     ============================================================ */

  const heroTime = document.getElementById('heroTime');
  const lastUpdated = document.getElementById('lastUpdated');
  const siteHeader = document.querySelector('.site-header');

  function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const timeString = `${hours}:${minutes}`;

    if (heroTime) {
      heroTime.textContent = timeString;
    }
  }

  function formatTimestamp() {
    const now = new Date();
    return now.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  }

  updateClock();
  setInterval(updateClock, 30000);

  if (lastUpdated) {
    lastUpdated.textContent = formatTimestamp();
  }

  // Header background on scroll
  function handleHeaderScroll() {
    if (!siteHeader) return;
    const scrollY = window.scrollY || document.documentElement.scrollTop || 0;
    if (scrollY > 40) {
      siteHeader.classList.add('scrolled');
    } else {
      siteHeader.classList.remove('scrolled');
    }
  }

  window.addEventListener('scroll', handleHeaderScroll, { passive: true });
  handleHeaderScroll();


  /* ============================================================
     2. MOBILE MENU & NAVIGATION
     ============================================================ */

  const menuToggle = document.getElementById('menuToggle');
  const navLinks = document.getElementById('navLinks');
  const navLinkItems = document.querySelectorAll('.nav-link');

  function closeMobileMenu() {
    if (navLinks && navLinks.classList.contains('open')) {
      navLinks.classList.remove('open');
      document.body.classList.remove('menu-open');
      if (menuToggle) {
        menuToggle.setAttribute('aria-expanded', 'false');
      }
    }
  }

  if (menuToggle && navLinks) {
    menuToggle.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = navLinks.classList.toggle('open');
      document.body.classList.toggle('menu-open', isOpen);
      menuToggle.setAttribute('aria-expanded', String(isOpen));
    });

    // Close when clicking nav link
    navLinkItems.forEach((link) => {
      link.addEventListener('click', () => {
        closeMobileMenu();
      });
    });

    // Close when clicking outside
    document.addEventListener('click', (e) => {
      if (
        navLinks.classList.contains('open') &&
        !navLinks.contains(e.target) &&
        !menuToggle.contains(e.target)
      ) {
        closeMobileMenu();
      }
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closeMobileMenu();
      }
    });
  }


  /* ============================================================
     3. ACTIVE NAVIGATION HIGHLIGHT ON SCROLL
     ============================================================ */

  const trackedSections = [
    { id: 'overview', linkHref: '#overview' },
    { id: 'problem', linkHref: '#overview' },
    { id: 'monitoring', linkHref: '#monitoring' },
    { id: 'prediction', linkHref: '#prediction' },
    { id: 'risk-map', linkHref: '#risk-map' },
    { id: 'workflow', linkHref: '#workflow' },
    { id: 'project', linkHref: '#project' },
    { id: 'roadmap', linkHref: '#project' }
  ];

  function updateActiveNavLink() {
    const scrollPos = (window.scrollY || document.documentElement.scrollTop || 0) + 180;
    let currentActiveHref = '#overview';

    for (let i = 0; i < trackedSections.length; i++) {
      const sectionEl = document.getElementById(trackedSections[i].id);
      if (sectionEl) {
        const top = sectionEl.offsetTop;
        const height = sectionEl.offsetHeight;
        if (scrollPos >= top && scrollPos < top + height) {
          currentActiveHref = trackedSections[i].linkHref;
          break;
        }
      }
    }

    navLinkItems.forEach((link) => {
      if (link.getAttribute('href') === currentActiveHref) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  }

  window.addEventListener('scroll', updateActiveNavLink, { passive: true });
  updateActiveNavLink();


  /* ============================================================
     4. SCROLL REVEAL ANIMATIONS
     ============================================================ */

  const revealElements = document.querySelectorAll('.reveal');

  if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.1,
        rootMargin: '0px 0px -40px 0px'
      }
    );

    revealElements.forEach((el) => {
      // If already in viewport on load, show immediately
      const rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight && rect.bottom > 0) {
        el.classList.add('visible');
      } else {
        revealObserver.observe(el);
      }
    });
  } else {
    // Fallback: make all elements visible immediately
    revealElements.forEach((el) => el.classList.add('visible'));
  }


  /* ============================================================
     5. MONITORING & RISK SIMULATION
     ============================================================ */

  // Metrics elements
  const tempValue = document.getElementById('tempValue');
  const tempMeter = document.getElementById('tempMeter');
  const tempScale = document.getElementById('tempScale');
  const heroTemp = document.getElementById('heroTemp');

  const humidityValue = document.getElementById('humidityValue');
  const humidityMeter = document.getElementById('humidityMeter');
  const heroHumidity = document.getElementById('heroHumidity');

  const windValue = document.getElementById('windValue');
  const windMeter = document.getElementById('windMeter');

  const rainValue = document.getElementById('rainValue');
  const rainMeter = document.getElementById('rainMeter');

  const smokeValue = document.getElementById('smokeValue');
  const smokeMeter = document.getElementById('smokeMeter');

  // Risk gauge elements
  const gaugeProgress = document.getElementById('gaugeProgress');
  const riskScoreEl = document.getElementById('riskScore');
  const riskLabelEl = document.getElementById('riskLabel');
  const riskMessageEl = document.getElementById('riskMessage');

  // Card status tags
  const tempStatus = document.querySelector('.metric-main .metric-status');
  const humidityStatus = document.querySelectorAll('.metric-card')[1]?.querySelector('.metric-status');
  const windStatus = document.querySelectorAll('.metric-card')[2]?.querySelector('.metric-status');
  const rainStatus = document.querySelectorAll('.metric-card')[3]?.querySelector('.metric-status');
  const smokeStatus = document.querySelector('.smoke-card .metric-status');

  const simulateBtn = document.getElementById('simulateBtn');

  // Gauge constants (r=86, circumference ≈ 540)
  const GAUGE_CIRCUMFERENCE = 540;

  function updateRiskGauge(score, levelInfo) {
    if (!gaugeProgress || !riskScoreEl || !riskLabelEl) return;

    const clampedScore = Math.max(0, Math.min(100, Math.round(score)));
    const offset = GAUGE_CIRCUMFERENCE * (1 - clampedScore / 100);

    // Animate score counter
    const currentScore = parseInt(riskScoreEl.textContent, 10) || clampedScore;
    const duration = 600;
    const startTime = performance.now();

    function stepScore(nowTime) {
      const elapsed = nowTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 3);
      const val = Math.round(currentScore + (clampedScore - currentScore) * ease);
      riskScoreEl.textContent = val;

      if (progress < 1) {
        requestAnimationFrame(stepScore);
      } else {
        riskScoreEl.textContent = clampedScore;
      }
    }
    requestAnimationFrame(stepScore);

    gaugeProgress.style.strokeDashoffset = offset;
    gaugeProgress.style.stroke = levelInfo.color;

    riskLabelEl.textContent = levelInfo.label;
    riskLabelEl.style.color = levelInfo.labelColor;

    if (riskMessageEl && levelInfo.message) {
      riskMessageEl.textContent = levelInfo.message;
    }
  }

  // Pre-configured realistic simulation scenarios for rich demonstration
  const scenarios = [
    {
      temp: 34,
      humidity: 42,
      wind: 18,
      rain: 2,
      smoke: 'Moderate',
      smokePercent: 52,
      tempStatus: { text: 'ELEVATED', class: 'elevated' },
      humidityStatus: { text: 'MODERATE', class: 'moderate' },
      windStatus: { text: 'ELEVATED', class: 'elevated' },
      rainStatus: { text: 'LOW', class: 'low' },
      smokeStatus: { text: 'ATTENTION', class: 'attention' },
      score: 58,
      level: {
        label: 'MODERATE RISK',
        color: '#e49a45',
        labelColor: 'var(--orange-light)',
        message: 'Demonstration conditions indicate a moderate level of wildfire risk. Elevated ambient temperatures and decreasing humidity require continuous canopy observation.'
      }
    },
    {
      temp: 39,
      humidity: 21,
      wind: 28,
      rain: 0,
      smoke: 'High',
      smokePercent: 78,
      tempStatus: { text: 'HIGH', class: 'elevated' },
      humidityStatus: { text: 'LOW', class: 'attention' },
      windStatus: { text: 'HIGH', class: 'elevated' },
      rainStatus: { text: 'ZERO', class: 'attention' },
      smokeStatus: { text: 'WARNING', class: 'attention' },
      score: 79,
      level: {
        label: 'HIGH RISK',
        color: '#b84a32',
        labelColor: '#f1a89b',
        message: 'High wildfire susceptibility detected. Severe atmospheric aridity, strong wind gusts, and detected particulate levels increase flame propagation speed.'
      }
    },
    {
      temp: 23,
      humidity: 76,
      wind: 9,
      rain: 14,
      smoke: 'Low',
      smokePercent: 18,
      tempStatus: { text: 'OPTIMAL', class: 'low' },
      humidityStatus: { text: 'HIGH', class: 'low' },
      windStatus: { text: 'CALM', class: 'low' },
      rainStatus: { text: 'ACTIVE', class: 'low' },
      smokeStatus: { text: 'CLEAR', class: 'low' },
      score: 22,
      level: {
        label: 'LOW RISK',
        color: '#6e9b76',
        labelColor: '#b0d9b6',
        message: 'Demonstration conditions indicate low wildfire risk. Recent rainfall and high relative moisture maintain fuel dampness across monitored zones.'
      }
    },
    {
      temp: 42,
      humidity: 15,
      wind: 36,
      rain: 0,
      smoke: 'Dense',
      smokePercent: 92,
      tempStatus: { text: 'CRITICAL', class: 'attention' },
      humidityStatus: { text: 'PARCHED', class: 'attention' },
      windStatus: { text: 'GUSTY', class: 'attention' },
      rainStatus: { text: 'DROUGHT', class: 'attention' },
      smokeStatus: { text: 'CRITICAL', class: 'attention' },
      score: 93,
      level: {
        label: 'CRITICAL RISK',
        color: '#812f25',
        labelColor: '#f59e93',
        message: 'Critical wildfire risk threshold reached. Extremely dry air, high wind velocity, and elevated smoke markers suggest immediate threat of ignition.'
      }
    },
    {
      temp: 29,
      humidity: 55,
      wind: 12,
      rain: 4,
      smoke: 'Low',
      smokePercent: 28,
      tempStatus: { text: 'MODERATE', class: 'moderate' },
      humidityStatus: { text: 'STABLE', class: 'low' },
      windStatus: { text: 'MODERATE', class: 'low' },
      rainStatus: { text: 'LIGHT', class: 'low' },
      smokeStatus: { text: 'NORMAL', class: 'low' },
      score: 38,
      level: {
        label: 'LOW RISK',
        color: '#6e9b76',
        labelColor: '#b0d9b6',
        message: 'Stable atmospheric parameters. Canopy moisture content remains sufficient, and wind turbulence is minimal across monitored quadrants.'
      }
    }
  ];

  let currentScenarioIndex = 0;

  function setStatusBadge(element, statusObj) {
    if (!element || !statusObj) return;
    element.textContent = statusObj.text;
    element.className = `metric-status ${statusObj.class}`;
  }

  function applyScenario(s) {
    // Temperature
    if (tempValue) tempValue.textContent = s.temp;
    if (tempMeter) tempMeter.style.width = `${Math.min(100, Math.round((s.temp / 50) * 100))}%`;
    if (tempScale) tempScale.textContent = `${Math.round((s.temp / 50) * 100)} / 100`;
    if (heroTemp) heroTemp.textContent = `${s.temp}°`;
    setStatusBadge(tempStatus, s.tempStatus);

    // Humidity
    if (humidityValue) humidityValue.textContent = s.humidity;
    if (humidityMeter) humidityMeter.style.width = `${s.humidity}%`;
    if (heroHumidity) heroHumidity.textContent = `${s.humidity}%`;
    setStatusBadge(humidityStatus, s.humidityStatus);

    // Wind
    if (windValue) windValue.textContent = s.wind;
    if (windMeter) windMeter.style.width = `${Math.min(100, Math.round((s.wind / 50) * 100))}%`;
    setStatusBadge(windStatus, s.windStatus);

    // Rain
    if (rainValue) rainValue.textContent = s.rain;
    if (rainMeter) rainMeter.style.width = `${Math.min(100, Math.round((s.rain / 25) * 100))}%`;
    setStatusBadge(rainStatus, s.rainStatus);

    // Smoke
    if (smokeValue) smokeValue.textContent = s.smoke;
    if (smokeMeter) smokeMeter.style.width = `${s.smokePercent}%`;
    setStatusBadge(smokeStatus, s.smokeStatus);

    // Risk Gauge
    updateRiskGauge(s.score, s.level);

    // Last updated
    if (lastUpdated) {
      lastUpdated.textContent = formatTimestamp();
    }
  }

  if (simulateBtn) {
    simulateBtn.addEventListener('click', () => {
      // Rotate icon for tactile feedback
      const icon = simulateBtn.querySelector('.simulate-icon');
      if (icon) {
        icon.style.transition = 'transform 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
        icon.style.transform = 'rotate(360deg)';
        setTimeout(() => {
          icon.style.transition = 'none';
          icon.style.transform = 'none';
        }, 500);
      }

      currentScenarioIndex = (currentScenarioIndex + 1) % scenarios.length;
      applyScenario(scenarios[currentScenarioIndex]);
    });
  }

  // Initialize gauge with default values on start
  updateRiskGauge(58, scenarios[0].level);


  /* ============================================================
     6. INTERACTIVE RISK MAP ZONES
     ============================================================ */

  const zoneButtons = document.querySelectorAll('.map-zone');
  const zoneIdEl = document.getElementById('zoneId');
  const zoneRiskEl = document.getElementById('zoneRisk');
  const zoneTitleEl = document.getElementById('zoneTitle');
  const zoneDescEl = document.getElementById('zoneDescription');
  const zoneTempEl = document.getElementById('zoneTemp');
  const zoneHumidityEl = document.getElementById('zoneHumidity');
  const zoneWindEl = document.getElementById('zoneWind');
  const zoneObsEl = document.getElementById('zoneObs');

  const zoneData = {
    A: {
      id: 'ZONE A',
      riskText: 'LOW RISK',
      riskClass: 'low',
      title: 'Stable environmental conditions',
      description: 'Demonstration zone with comparatively lower risk indicators, moist vegetation, and moderate wind currents.',
      temp: '29°C',
      humidity: '58%',
      wind: '10 km/h',
      obs: 'Stable'
    },
    B: {
      id: 'ZONE B',
      riskText: 'MODERATE RISK',
      riskClass: 'moderate',
      title: 'Elevated temperature corridor',
      description: 'Sun-exposed ridge experiencing rising midday temperatures, localized dry breezes, and dropping fuel moisture.',
      temp: '35°C',
      humidity: '39%',
      wind: '22 km/h',
      obs: 'Monitoring'
    },
    C: {
      id: 'ZONE C',
      riskText: 'HIGH RISK',
      riskClass: 'high',
      title: 'Critical dry canyon area',
      description: 'Steep ravine topography with parched underbrush, thermal updrafts, and increased vulnerability to fast-moving ignition.',
      temp: '41°C',
      humidity: '21%',
      wind: '34 km/h',
      obs: 'Alert Active'
    },
    D: {
      id: 'ZONE D',
      riskText: 'LOW RISK',
      riskClass: 'low',
      title: 'Protected valley sector',
      description: 'Dense mixed hardwood canopy with sheltered valley microclimate, morning condensation, and high moisture retention.',
      temp: '26°C',
      humidity: '64%',
      wind: '8 km/h',
      obs: 'Stable'
    }
  };

  zoneButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const zoneKey = btn.getAttribute('data-zone');
      const data = zoneData[zoneKey];
      if (!data) return;

      zoneButtons.forEach((b) => b.classList.remove('selected'));
      btn.classList.add('selected');

      if (zoneIdEl) zoneIdEl.textContent = data.id;
      if (zoneRiskEl) {
        zoneRiskEl.textContent = data.riskText;
        zoneRiskEl.className = `risk-tag ${data.riskClass}`;
      }
      if (zoneTitleEl) zoneTitleEl.textContent = data.title;
      if (zoneDescEl) zoneDescEl.textContent = data.description;
      if (zoneTempEl) zoneTempEl.textContent = data.temp;
      if (zoneHumidityEl) zoneHumidityEl.textContent = data.humidity;
      if (zoneWindEl) zoneWindEl.textContent = data.wind;
      if (zoneObsEl) zoneObsEl.textContent = data.obs;
    });
  });


  /* ============================================================
     7. SYSTEM WORKFLOW ACCORDION
     ============================================================ */

  const workflowRows = document.querySelectorAll('.workflow-row');
  const workflowDetails = document.querySelectorAll('.workflow-detail');

  workflowRows.forEach((row, index) => {
    row.addEventListener('click', () => {
      const isAlreadyActive = row.classList.contains('active');

      // Close all
      workflowRows.forEach((r) => r.classList.remove('active'));
      workflowDetails.forEach((d) => d.classList.remove('open'));

      // If it wasn't active, activate it
      if (!isAlreadyActive) {
        row.classList.add('active');
        if (workflowDetails[index]) {
          workflowDetails[index].classList.add('open');
        }
      }
    });
  });


  /* ============================================================
     8. PROJECT ROADMAP ACCORDION & PROGRESS
     ============================================================ */

  const roadmapItems = document.querySelectorAll('.roadmap-item');
  const roadmapDetails = document.querySelectorAll('.roadmap-detail');
  const roadmapProgressBar = document.querySelector('.roadmap-progress span');

  function updateRoadmapProgress(activeIndex) {
    if (!roadmapProgressBar) return;
    const total = roadmapItems.length || 6;
    const percent = Math.min(100, Math.round(((activeIndex + 1) / total) * 100));
    roadmapProgressBar.style.height = `${percent}%`;
  }

  roadmapItems.forEach((item, index) => {
    item.addEventListener('click', () => {
      const isAlreadyActive = item.classList.contains('active');

      roadmapItems.forEach((it) => it.classList.remove('active'));
      roadmapDetails.forEach((dt) => dt.classList.remove('open'));

      if (!isAlreadyActive) {
        item.classList.add('active');
        if (roadmapDetails[index]) {
          roadmapDetails[index].classList.add('open');
        }
        updateRoadmapProgress(index);
      }
    });
  });


  /* ============================================================
     9. BACK TO TOP BUTTON
     ============================================================ */

  const backTopBtn = document.getElementById('backTop');

  if (backTopBtn) {
    window.addEventListener(
      'scroll',
      () => {
        if (window.scrollY > 400) {
          backTopBtn.classList.add('show');
        } else {
          backTopBtn.classList.remove('show');
        }
      },
      { passive: true }
    );

    backTopBtn.addEventListener('click', () => {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initEmberWatch);
} else {
  initEmberWatch();
}
